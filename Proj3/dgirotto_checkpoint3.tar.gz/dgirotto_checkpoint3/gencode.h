#ifndef _CODEGEN_H_
#define _CODEGEN_H_

void genCode(TreeNode*);


#endif
