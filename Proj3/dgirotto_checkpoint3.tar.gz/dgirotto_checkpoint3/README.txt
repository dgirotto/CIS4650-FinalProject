COMPILERS CHECKPOINT 4:

1. type make to compile the source code
2. to run any of the test programs type ./cminus <nameoffile> 
