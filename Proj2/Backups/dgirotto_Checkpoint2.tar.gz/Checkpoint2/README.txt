README.txt
CIS4650	Checkpoint 2
Name: Daniel Girotto
ID: 0783831
Date: Wed March 23 2016
--------------------------------------

1. unzip the .tar.gz file
2. navigate into the "Checkpoint2" folder
3. type "make" which will compile and build the program
4. type "./cminus <file_here>" to execute syntactic and semantic analysis on the file provided
5. type "make clean" to clean up the directory of its object and executable files
